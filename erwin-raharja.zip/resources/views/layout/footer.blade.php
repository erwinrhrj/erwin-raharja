<footer class="e-bg-dark text-center text-white">
    <div class="container p-4 pb-4">
        {{-- S: MEDIA SOCIAL --}}
        <!--<section class="">
            {{-- S: FACEBOOK --}}
                <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                    <i class="fa-brands fa-facebook-f fa-lg"></i>
                </a>
            {{-- E: FACEBOOK --}}
            {{-- S: INSTAGRAM --}}
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-instagram fa-lg"></i>
            </a>
            {{-- E: INSTAGRAM --}}
            {{-- S: GOOGLE --}}
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-google fa-lg"></i>
            </a>
            {{-- E: GOOGLE --}}
            {{-- S: LINKEDIN --}}
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-linkedin fa-lg"></i>
            </a>
            {{-- E: LINKEDIN --}}
            {{-- S: GITHUB --}}
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-github fa-lg"></i>
            </a>
            {{-- E: GITHUB --}}
        </section>-->
        {{-- E: MEDIA SOCIAL --}}
    </div>

    {{-- COPYRIGHT --}}
    {{-- <div class="text-center p-3" style="background-color: #1E1E1E">
        2020 Copyright:
        <a href="" class="text-white"> Erwin Raharja</a>
    </div> --}}
</footer>