<nav class="navbar navbar-expand-lg navbar-dark e-nav-bg e-navbar-fixed">
    <div class="container-fluid">
        
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto e-nav-font-style pe-4">              	
                <a href="#home" class="nav-item nav-link pe-3 fw-bold">HOME</a>
                <a href="#profile" class="nav-item nav-link pe-3 fw-bold">PROFILE</a>
                <a href="#experiences" class="nav-item nav-link pe-3 fw-bold">EXPERIENCES</a>
                <a href="#abilities" class="nav-item nav-link pe-3 fw-bold">ABILITIES</a>
                <a href="" class="nav-item nav-link pe-3 fw-bold">PROJECTS</a>
                <a href="#contact" class="nav-item nav-link pe-3 fw-bold">CONTACT</a>  
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\erwin-raharja\resources\views/layout/header.blade.php ENDPATH**/ ?>