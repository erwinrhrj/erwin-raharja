<footer class="e-bg-dark text-center text-white">
    <div class="container p-4 pb-4">
        
        <!--<section class="">
            
                <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                    <i class="fa-brands fa-facebook-f fa-lg"></i>
                </a>
            
            
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-instagram fa-lg"></i>
            </a>
            
            
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-google fa-lg"></i>
            </a>
            
            
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-linkedin fa-lg"></i>
            </a>
            
            
            <a href="#" class="btn btn-outline-light e-btn-floating m-1" role="button">
                <i class="fa-brands fa-github fa-lg"></i>
            </a>
            
        </section>-->
        
    </div>

    
    
</footer><?php /**PATH C:\xampp\htdocs\erwin-raharja\resources\views/layout/footer.blade.php ENDPATH**/ ?>